package br.unipar.programacaointernet.clinica.controller;

import br.unipar.programacaointernet.clinica.model.Medico;
import br.unipar.programacaointernet.clinica.model.Paciente;
import br.unipar.programacaointernet.clinica.service.MedicoService;
import br.unipar.programacaointernet.clinica.service.PacienteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Tag(name = "Médico API", description = "API para gerenciamento dos usuários médicos")
public class MedicoApiController {

    private final MedicoService medicoService;

    public MedicoApiController(MedicoService medicoService) {
        this.medicoService = medicoService;
    }

    @GetMapping(path = "/api/medicos")
    @Operation(summary = "Obter todos os médicos", description = "Retorna uma lista de todos os médicos")
    public ResponseEntity<List<Medico>> getAll(){
        return ResponseEntity.ok(medicoService.getAll());
    }
    @PostMapping(path = "/api/medicos")
    @Operation(summary = "Salvar médico",
            description = "Salva um novo médico e retorna o médico salvo",
            parameters = {
                    @Parameter(name = "medico", description = "Médico que será adicionado. " +
                            "Não é necessário incluir o ID.")
            })
    public ResponseEntity<Medico> save(@RequestBody Medico medico){
        return ResponseEntity.ok(medicoService.save(medico));
    }
}
